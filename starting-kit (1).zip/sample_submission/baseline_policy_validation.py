import numpy as np
from typing import List, Optional
from stable_baselines3 import PPO

from policy_validation import PolicyValidation


class BaselinePolicyValidation(PolicyValidation):
    def __init__(self, initial_states_path, policy_model_path):
        self.initial_states = np.load(initial_states_path)
        self.policy_model = PPO.load(policy_model_path)
        self.cur_day_total_order_num = 0
        self.cur_day_roi = 0.0

    def _states_to_obs(self, states: np.ndarray):
        """Reduce the dimension of states by transforming the states of each user to a single observation of all users' community.
        We use a naive method here: compute the mean, std, max and min value of each dimension,
        concatenated with current day's total number of orders and ROI.

        Return:
            A depiction of user community (np.array).
        """
        assert len(states.shape) == 2
        mean_obs = np.mean(states, axis=0)
        std_obs = np.std(states, axis=0)
        max_obs = np.max(states, axis=0)
        min_obs = np.min(states, axis=0)
        day_total_order_num, day_roi = np.array([self.cur_day_total_order_num]), np.array([self.cur_day_roi])
        return np.concatenate([mean_obs, std_obs, max_obs, min_obs, day_total_order_num, day_roi], 0)

    def get_next_states(self, cur_states: Optional[List[np.ndarray]], coupon_action: np.ndarray, user_actions: List[np.ndarray]):
        user_actions_array = np.array(user_actions)
        day_order_num, day_avg_fee = user_actions_array[:, [0]], user_actions_array[:, [1]]
        coupon_num, discount = coupon_action[0], coupon_action[1]

        next_states = np.empty(cur_states.shape)
        size_array = np.array([[x[0] / x[1] if x[1] > 0 else 0] for i, x in enumerate(cur_states)])
        next_states[:, [0]] = cur_states[:, [0]] + day_order_num
        next_states[:, [1]] = cur_states[:, [1]] + 1 / (size_array + 1) * (day_order_num - cur_states[:, [1]]) * (day_order_num > 0.0).astype(np.float32)
        next_states[:, [2]] = cur_states[:, [2]] + 1 / (size_array + 1) * (day_avg_fee - cur_states[:, [2]]) * (day_avg_fee > 0.0).astype(np.float32)

        self.cur_day_total_order_num = np.sum(day_order_num)
        day_coupon_used_num = np.min(np.concatenate([day_order_num, coupon_num * np.ones(day_order_num.shape)], -1), -1, keepdims=True)
        cost_array = (1 - discount) * day_coupon_used_num * day_avg_fee
        gmv_array = day_avg_fee * day_order_num - cost_array
        self.cur_day_roi = np.sum(gmv_array) / max(np.sum(cost_array), 1)
        return next_states

    def get_action_from_policy(self, user_states: Optional[List[np.ndarray]]=None):
        obs = self._states_to_obs(user_states)
        action, _ = self.policy_model.predict(obs, deterministic=False)
        action = action.astype(np.float32)
        action[1] = 0.95 - 0.05 * action[1]

        return action
